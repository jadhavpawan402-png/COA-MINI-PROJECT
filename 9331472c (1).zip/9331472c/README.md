# CPU Instruction Cycle Simulator — Fetch, Decode, Execute

**Computer Organisation and Architecture (COA) micro-project**

A single-page website that shows, step by step, how a CPU runs a program: it **fetches** an
instruction from memory, **decodes** it to find the opcode and operands, and **executes** it by
updating registers or memory. Every value on the screen comes from one JavaScript state object,
so the display can never disagree with the simulation.

Built with **only HTML + CSS + JavaScript** — no frameworks, no libraries, no server, no internet.

---

## 1. How to run it locally

1. Save `index.html` anywhere on your computer.
2. **Double-click `index.html`** — it opens in your default browser.
   (Or right-click → *Open with* → Chrome / Edge / Firefox.)
3. The sample program is already loaded, so you can press **Fetch** immediately.

That is all. It works offline and needs no installation.

> If your college machine blocks `file://` pages, start a tiny local server in the same folder
> with `python -m http.server 8000` and open `http://localhost:8000`. This is optional.

### Buttons

| Button | What it does |
|---|---|
| **Fetch** | Runs the whole fetch stage (4 micro-operations) |
| **Decode** | Runs the whole decode stage (2 micro-operations) |
| **Execute** | Runs the whole execute stage (1–3 micro-operations) |
| **Next Step** | Runs **one** micro-operation only |
| **Run Program** | Runs everything automatically; the same button becomes **Pause** |
| **Reset** | Reads the input boxes again and restores the starting state |
| **Load Example** | Puts the sample program and its memory values into the input boxes |

Stage buttons are order-checked: pressing **Decode** before **Fetch** shows
*"Wrong order: the FETCH stage must be completed before you can use Decode."*

---

## 2. The CPU model used

| Component | Full form | Job in this simulator |
|---|---|---|
| **PC** | Program Counter | Holds the address of the **next** instruction |
| **MAR** | Memory Address Register | Holds the address of the memory word being read/written |
| **MDR** | Memory Data Register | Holds the data travelling to/from memory |
| **IR** | Instruction Register | Holds the instruction being executed |
| **CU** | Control Unit | Reads the IR, identifies opcode + operands, sends control signals |
| **ALU** | Arithmetic Logic Unit | Performs ADD, SUB and INC |
| **R0–R3** | General purpose registers | Hold the numbers the program works on |
| **Instruction Memory** | — | Holds the program; addresses `0, 1, 2 …` |
| **Data Memory** | — | Holds data; addresses `0` to `15` |

**Memory sizes:** instruction memory is exactly as long as your program; data memory has 16 words.
**Numbers:** plain whole numbers (negatives allowed). Overflow and word size are *not* modelled —
this keeps the simulator simple.
**Program end:** the program finishes when PC becomes greater than the last instruction address.

### The three stages as micro-operations

**Fetch** — identical for every instruction:
```
MAR ← PC
MDR ← InstructionMemory[MAR]
IR  ← MDR
PC  ← PC + 1
```

**Decode** — the Control Unit works on the IR:
```
CU identifies the opcode    (what operation is it?)
CU identifies the operands  (which registers / addresses / values?)
```

**Execute** — depends on the instruction, for example `LOAD R1, 10`:
```
MAR ← 10
MDR ← DataMemory[MAR]
R1  ← MDR
```
and `ADD R3, R1, R2`:
```
ALU ← R1 + R2
R3  ← ALU
```

The component boxes involved in the current micro-operation turn **orange**, the matching memory
cell turns orange too, and the stage card ticks the micro-operations off one by one.

---

## 3. Instruction set

| Instruction | Syntax | Meaning | Example |
|---|---|---|---|
| `MOV` | `MOV Rx, value` or `MOV Rx, Ry` | Put a value / a copy of another register into Rx | `MOV R1, 5` |
| `LOAD` | `LOAD Rx, address` | `Rx ← DataMemory[address]` | `LOAD R1, 10` |
| `STORE` | `STORE Rx, address` | `DataMemory[address] ← Rx` | `STORE R3, 12` |
| `ADD` | `ADD Rd, Rs1, Rs2` or `ADD Rd, Rs` | `Rd ← Rs1 + Rs2` (2-operand form: `Rd ← Rd + Rs`) | `ADD R3, R1, R2` |
| `SUB` | `SUB Rd, Rs1, Rs2` or `SUB Rd, Rs` | `Rd ← Rs1 − Rs2` (2-operand form: `Rd ← Rd − Rs`) | `SUB R0, R3, R0` |
| `INC` | `INC Rx` | `Rx ← Rx + 1` | `INC R0` |
| `JMP` | `JMP address` | `PC ← address` (must be an existing instruction address) | `JMP 8` |

Rules: registers are `R0 R1 R2 R3` only; values must be whole numbers; data memory addresses are
`0`–`15`; one instruction per line; `;` or `#` starts a comment; blank lines and comments are
ignored, so an instruction's **address is its position in the assembled list** (shown in the
Instruction Memory panel). Upper/lower case both work.

---

## 4. Sample program and its expected result

```
; Sample program: add two numbers from data memory
LOAD R1, 10     ; R1 <- Memory[10]  (5)
LOAD R2, 11     ; R2 <- Memory[11]  (7)
ADD R3, R1, R2  ; R3 <- 5 + 7 = 12
STORE R3, 12    ; Memory[12] <- 12
MOV R0, 3       ; R0 <- 3
INC R0          ; R0 <- 3 + 1 = 4
SUB R0, R3, R0  ; R0 <- 12 - 4 = 8
JMP 8           ; jump to instruction address 8
STORE R0, 13    ; Memory[13] <- 8, then the program ends
```

Data memory starts with **5 at address 10** and **7 at address 11**; all registers start at 0;
PC starts at 0.

**Expected final state (verified):**

| Item | Value |
|---|---|
| R0 | 8 |
| R1 | 5 |
| R2 | 7 |
| R3 | 12 |
| DataMemory[12] | 12 |
| DataMemory[13] | 8 |
| PC | 9 (past the last instruction → program finished) |
| Micro-operations performed | **74** |

Step count check: 9 instructions × (4 fetch + 2 decode) = 54, plus execute steps
3+3+2+3+1+2+2+1+3 = 20 → **74**.

---

## 5. Test cases

All of these were run in a browser and gave the results shown.

| # | Input | Action | Expected result |
|---|---|---|---|
| 1 | Sample program, PC=0, Mem[10]=5, Mem[11]=7 | **Next Step** ×74 | R0=8, R1=5, R2=7, R3=12, Mem[12]=12, Mem[13]=8, PC=9, message *"Program finished after 74 micro-operations"* |
| 2 | Sample program | **Next Step** ×9 (one full `LOAD R1, 10`) | MAR=10, MDR=5, IR=`LOAD R1, 10`, PC=1, R1=5, log shows FETCH 4 → DECODE 2 → EXECUTE 3 |
| 3 | `MOV R2, 21` / `INC R2` / `STORE R2, 5` | **Run Program** | R2=22, Mem[5]=22, PC=3, 24 micro-operations, then *Program finished* |
| 4 | R0=4, R1=6, Mem[0]=10, Mem[1]=3; program `ADD R2, R0, R1` / `SUB R3, R0, R1` / `INC R3` / `MOV R1, R2` / `ADD R1, R3` / `LOAD R0, 0` / `STORE R1, 1` / `SUB R2, R2` | **Run Program** | R0=10, R1=9, R2=0, R3=**−1**, Mem[1]=9 — proves negatives and the 2-operand ADD/SUB forms work |
| 5 | `LOAD R1, 10` / `FOO R2` | **Reset** | Error: *Instruction at address 1 ("FOO R2") is not valid: Unknown instruction "FOO"…* |
| 6 | `LOAD R1, 99` | **Reset** | Error: *Data memory address 99 does not exist. Valid addresses are 0 to 15.* |
| 7 | `STORE R1, -3` | **Reset** | Error: *Data memory address −3 does not exist…* |
| 8 | `ADD R1, R5, R2` | **Reset** | Error: *"R5" is not a register. ADD works only on R0-R3.* |
| 9 | `MOV R1, 2` / `JMP 5` | **Reset** | Error: *Cannot jump to address 5. This program has instructions 0 to 1 only.* |
| 10 | `MOV R1` | **Reset** | Error: *"MOV R1" is not correct. Use: MOV Rx, value or MOV Rx, Ry* |
| 11 | `MOV R1, abc` | **Reset** | Error: *"ABC" is neither a register (R0-R3) nor a whole number.* |
| 12 | program box contains only a comment | **Reset** | Error: *The program is empty…* |
| 13 | 2-instruction program, initial PC = 5 | **Reset** | Error: *The initial PC (5) is outside the program. Valid instruction addresses are 0 to 1.* |
| 14 | Sample program, in FETCH stage | press **Decode** | Error: *Wrong order: the FETCH stage must be completed before you can use "Decode"…* — and nothing changes |
| 15 | Sample program, initial PC = 4 | **Run Program** | Starts at instruction 4; the log shows *── Instruction 4: "MOV R0, 3" ──* and the Instruction Memory panel highlights row 4 |
| 16 | `INC R0` / `JMP 0` (endless loop) | **Run Program** | Runs automatically, then stops by itself at the 600-step safety limit with *…the program probably contains an endless JMP loop* |
| 17 | Any program after it finishes | press **Fetch** | Message: *The program has already finished. Press Reset to run it again.* |
| 18 | Sample program, change Mem[10] to 100 | **Reset** then run | R1=100, R3=107, Mem[12]=107, R0=103, Mem[13]=103 — new initial values are applied |

---

## 6. How the code works (for your viva)

Everything is inside one `<script>` block at the bottom of `index.html`, split into 8 numbered
parts.

### Part 1 — Constants and CPU state
- `DATA_MEM_SIZE = 16`, `RUN_DELAY = 450` (ms between automatic steps), `MAX_AUTO_STEPS = 600`
  (safety limit against endless `JMP` loops).
- **`cpu`** — one object holding the entire machine: `pc`, `mar`, `mdr`, `ir`, `alu`,
  `regs[4]`, `dataMem[16]`, `instrMem[]`. *This is the single source of truth; the screen is
  only a picture of it.*
- Control variables: `phase` (`FETCH`/`DECODE`/`EXECUTE`/`DONE`), `microSteps` (the list of
  micro-operations for the current stage), `microIndex` (which one runs next), `decoded`
  (output of the decode stage), `halted` (set after an error), `totalSteps`, `lastResult`,
  `activeParts` (which boxes are orange), `stageCache` (labels shown in the three stage cards),
  `runTimer` (the `setInterval` id used by Run Program).
- `EXAMPLE_PROGRAM` and `EXAMPLE_MEMORY` hold the sample data.

### Part 2 — Helpers
- `el(id)` — short for `document.getElementById`.
- `toInt(text)` — returns a number only for whole numbers, otherwise `null` (used everywhere for
  validation).
- `regNo(token)` — returns 0–3 for `"R0"`–`"R3"`, otherwise `null`.
- `splitProgram(text)` — removes comments (`;` `#`) and blank lines, upper-cases the rest, and
  returns the instruction list. The index in this list **is** the instruction address.
- `setMessage(text, kind)` — writes the coloured message bar (`kind` = `'ok'`, `'error'` or `''`).
- `addLog(text, kind)` — appends a line to the execution log and scrolls to the bottom.

### Part 3 — `decodeText(text, programLength)`
The heart of validation. It splits the instruction into tokens, checks the opcode against the
`SYNTAX` table, then checks operand count, register names and address ranges **per instruction**.
It returns either `{ error: "message" }` or an object with the decoded fields
(`{opcode:'LOAD', reg:1, addr:10}`).
The same function is used twice: once by `loadSettings()` to check the whole program before it
runs, and again during the real decode stage. `describeOperands(d)` turns that object into a
readable sentence for the screen.

### Part 4 — Building the micro-operations
A micro-operation is a small object made by `micro(label, description, parts, action)`:
- `label` — for example `MAR ← PC`, shown in the log and stage card;
- `description` — the plain-English explanation shown in the Output panel;
- `parts` — the component boxes to highlight (`['pc','mar']`);
- `action` — a function that changes the `cpu` object. **It returns a string if something is
  wrong**, which is how errors reach the screen.

Three builders: `buildFetchSteps()` (always the same 4 steps), `buildDecodeSteps()` (2 steps),
and `buildExecuteSteps(d)` (a `switch` on the opcode: LOAD and STORE need 3 steps because data
goes through MAR and MDR, ADD/SUB/INC need 2 because the ALU computes and then writes back,
MOV and JMP need 1).

### Part 5 — The engine
- `enterFetch()`, `enterDecode()`, `enterExecute()` set `phase`, build `microSteps`, reset
  `microIndex` and refresh `stageCache`.
- `nextPhase()` moves FETCH → DECODE → EXECUTE → (next instruction's FETCH, or DONE).
- `finishInstruction()` reports the result, then either starts the next fetch or declares the
  program finished when `pc >= instrMem.length`.
- **`stepOnce()` is the most important function.** It performs exactly one micro-operation:
  highlight the parts → call `action()` → count the step → if `action()` returned a string call
  `stopWithError()` → otherwise write the log line, update the Output panel, advance
  `microIndex`, change phase if the stage is finished, and re-draw with `render()`.
- `runStage()` simply calls `stepOnce()` in a `while` loop until the phase changes — that is all
  the **Fetch / Decode / Execute** buttons do.
- `checkOrder()` produces the "wrong order" message and stops the button from doing anything.

### Part 6 — Button handlers
`onFetch`, `onDecode`, `onExecute`, `onNextStep`, `onRun` (toggles a `setInterval`; the button
text flips to *Pause*), `stopRun`, `onReset`, `onLoadExample`, and `loadSettings()` — which reads
and validates every input box and only then copies the values into the `cpu` object.

### Part 7 — Drawing
`render()` copies the `cpu` object onto the page: component values, the instruction memory list,
the 16 data memory cells, the three stage cards and the Output panel. `highlight()` /
`clearHighlight()` add or remove the orange `.active` class. Because `render()` is called after
every micro-operation, the display always matches the state.

### Part 8 — Start-up
A small loop creates the 16 initial-data-memory input boxes, the seven buttons get their
`click` listeners, and `onLoadExample()` runs once so the page opens ready to use.

---

## 7. Likely viva questions

**What is the difference between MAR and MDR?**
MAR holds *where* (the address); MDR holds *what* (the data or instruction being transferred).

**Why is PC incremented during fetch and not during execute?**
So that the next instruction address is already ready. A `JMP` simply overwrites PC during
execute, which is why a jump works with no extra hardware.

**What does the Control Unit do?**
It reads the IR, identifies the opcode and operands (the decode stage), and then generates the
control signals that move data between PC, MAR, MDR, registers, ALU and memory.

**Which registers does the ALU use?**
The ALU reads two registers and produces a result; a second micro-operation writes that result
back into the destination register. `INC` also uses the ALU (it is an add with the constant 1).

**How does the simulator know the program has ended?**
There is no HALT instruction. When PC becomes equal to or greater than the number of
instructions, there is nothing left to fetch, so the state becomes `DONE`.

**What happens with an endless `JMP` loop?**
"Run Program" stops by itself after 600 micro-operations and explains that the program probably
contains an endless loop.

**Why can't I press Decode before Fetch?**
`checkOrder()` compares the current `phase` with the phase the button needs and refuses with a
message, exactly like real hardware where the stages must happen in order.

**Where does the data come from for `LOAD`?**
Data Memory. The address goes into MAR, the value comes back over the data bus into MDR, and
from MDR into the register.

---

## 8. Suggested screenshots for your report

1. **Full page after opening** — header, program box, controls, the three stage cards.
2. **After pressing Fetch once** — PC/MAR/MDR/IR filled in, the FETCH card highlighted, log
   showing the four fetch micro-operations.
3. **After Decode** — Output panel showing *"Opcode = LOAD → read a value from data memory into a
   register"* and the operand sentence.
4. **During Execute of `LOAD R1, 10`** — the orange MAR/MDR/R1 boxes and the orange data memory
   cell 10 (this is the best single picture of the data path).
5. **After `ADD R3, R1, R2`** — ALU box showing 12 and R3 = 12.
6. **After `STORE R3, 12`** — data memory cell 12 showing 12.
7. **Program finished** — final register values, Mem[12]=12, Mem[13]=8, PC=9, "74 micro-operations".
8. **An error message** — e.g. `LOAD R1, 99` after Reset (red message bar).
9. **Wrong-order message** — pressing Decode while still in the FETCH stage.
10. **The CPU block diagram** section of the page.
11. **The instruction cycle flowchart** section of the page.
12. **The execution log** scrolled to the end, showing the Fetch/Decode/Execute pattern for the
    last few instructions.

Tip: use `Win + Shift + S` (Windows) to capture a region, and press **Reset** between screenshots
so each one starts from a clean state.

---

## 9. Known limitations (good to mention in the viva)

- No `HALT` instruction; the program ends when PC runs past the last instruction.
- No conditional jumps or flags (zero/carry), so every backward `JMP` loops forever — the
  600-step limit catches it.
- No word size, overflow, pipelining, interrupts or I/O.
- Instruction memory and data memory are separate (a simple Harvard-style model), which is why
  `JMP` uses instruction addresses while `LOAD`/`STORE` use data addresses.
- Numbers are unlimited-precision integers; a real CPU would wrap around on overflow.

---

## 10. Files

| File | Purpose |
|---|---|
| `index.html` | The entire project — HTML structure, CSS styling and JavaScript simulator |
| `README.md` | This document |
